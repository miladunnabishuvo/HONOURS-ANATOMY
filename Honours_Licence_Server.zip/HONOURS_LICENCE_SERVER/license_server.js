#!/usr/bin/env node
/* Honours Anatomy licence server. No dependencies. Node 18+.
   Server:  node license_server.js
   Admin :  node license_server.js add "Student Name" --devices 2 --days 365
            node license_server.js list | revoke CODE | unrevoke CODE | reset CODE | extend CODE DAYS
*/
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const DIR=process.env.DATA_DIR||__dirname,DB=path.join(DIR,'licenses.json'),PORT=process.env.PORT||8787;
const KEY=(process.env.CONTENT_KEY||(fs.existsSync(path.join(__dirname,'content.key'))?fs.readFileSync(path.join(__dirname,'content.key'),'utf8'):'')).trim();
const load=()=>{try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch(e){return{}}};
const save=d=>{const t=DB+'.tmp';fs.writeFileSync(t,JSON.stringify(d,null,1));fs.renameSync(t,DB)};
const norm=c=>String(c||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const fmt=c=>'HMP-'+c.slice(0,4)+'-'+c.slice(4,8)+'-'+c.slice(8,12);
const newCode=()=>{const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(const b of crypto.randomBytes(12))s+=A[b%A.length];return s};
const find=(db,code)=>{const n=norm(code),k=Object.keys(db).find(x=>norm(x)===n||norm(x)==='HMP'+n||'HMP'+n===norm(x));return k};
const a=process.argv.slice(2);
if(a[0]&&a[0]!=='serve'){
  const db=load(),opt=n=>{const i=a.indexOf('--'+n);return i>-1?a[i+1]:null};
  if(a[0]==='add'){const c=fmt(newCode()),days=+(opt('days')||365),dev=+(opt('devices')||2);db[c]={name:a[1]||'Student',maxDevices:dev,devices:[],expires:Date.now()+days*864e5,revoked:false,created:Date.now()};save(db);console.log(c+'   '+(a[1]||'Student')+'   devices:'+dev+'   valid '+days+' days')}
  else if(a[0]==='list'){for(const[c,l]of Object.entries(db))console.log(c.padEnd(18),l.name.padEnd(22),(l.revoked?'REVOKED':new Date(l.expires)<new Date()?'EXPIRED':'active').padEnd(8),'devices '+l.devices.length+'/'+l.maxDevices,'expires '+new Date(l.expires).toISOString().slice(0,10))}
  else{const k=find(db,a[1]);if(!k){console.log('Code not found');process.exit(1)}
    if(a[0]==='revoke')db[k].revoked=true;else if(a[0]==='unrevoke')db[k].revoked=false;else if(a[0]==='reset')db[k].devices=[];else if(a[0]==='extend')db[k].expires=Math.max(Date.now(),db[k].expires)+(+a[2]||30)*864e5;else{console.log('Unknown command');process.exit(1)}
    save(db);console.log('Done:',k)}
  process.exit(0)}
if(!KEY){console.error('Missing content.key (or CONTENT_KEY env).');process.exit(1)}
const hits={};
const limited=ip=>{const t=Date.now(),h=(hits[ip]=(hits[ip]||[]).filter(x=>t-x<6e4));h.push(t);return h.length>30};
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
http.createServer((req,res)=>{
  if(req.method==='OPTIONS')return send(res,204,{});
  if(req.url==='/health')return send(res,200,{ok:true});
  if(req.method!=='POST'||!/^\/(activate|check)$/.test(req.url))return send(res,404,{error:'Not found'});
  const ip=req.headers['x-forwarded-for']||req.socket.remoteAddress;if(limited(ip))return send(res,429,{error:'Too many attempts. Try again in a minute.'});
  let body='';req.on('data',c=>{body+=c;if(body.length>4096)req.destroy()});
  req.on('end',()=>{let j;try{j=JSON.parse(body)}catch(e){return send(res,400,{error:'Bad request'})}
    const db=load(),k=find(db,j.code),dev=String(j.device||'').slice(0,64);
    if(!k||!dev)return send(res,404,{error:'That licence code is not valid.',fatal:true});
    const l=db[k];
    if(l.revoked)return send(res,403,{error:'This licence has been disabled. Contact Honours Medical Publications.',fatal:true});
    if(Date.now()>l.expires)return send(res,403,{error:'This licence has expired.',fatal:true});
    const has=l.devices.includes(dev);
    if(req.url==='/activate'&&!has){if(l.devices.length>=l.maxDevices)return send(res,409,{error:'Device limit reached for this code ('+l.maxDevices+'). Contact Honours Medical Publications to reset it.',fatal:true});l.devices.push(dev);save(db)}
    if(req.url==='/check'&&!has)return send(res,409,{error:'This device is not registered for this licence.',fatal:true});
    send(res,200,req.url==='/activate'?{key:KEY,name:l.name,exp:l.expires}:{ok:true,name:l.name,exp:l.expires})});
}).listen(PORT,()=>console.log('Licence server listening on '+PORT));
