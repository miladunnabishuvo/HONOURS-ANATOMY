# Honours Anatomy – licence server

Checks licence codes, limits devices per code, supports expiry and revocation, and gives the app its unlock key.
No dependencies. Needs Node.js 18 or newer.

**Keep this folder private.** `content.key` is the secret that unlocks the book. Anyone who has it can read the content.

## 1. Run it
    node license_server.js          # starts on port 8787 (set PORT to change)

It must be reachable over **https** for the Android app. Easy options:
- A small VPS (Hetzner, DigitalOcean, etc.): run it with `pm2 start license_server.js`, and put Caddy or nginx in front for https.
- Render, Railway or Fly.io: deploy this folder. Use a **persistent disk** and set `DATA_DIR` to its path, or the licence list is lost when the service restarts.
Set `CONTENT_KEY` as an environment variable instead of shipping `content.key` if your host supports secrets (value = the text inside content.key).

## 2. Put the address in the app
Open the protected `index.html`, find `var LICENSE_SERVER="https://YOUR-LICENSE-SERVER.example.com";` and replace it with your address (no trailing slash). Or send me the address and I will rebuild it.

## 3. Manage licences (run in this folder, or the server shell)
    node license_server.js add "Student Name" --devices 2 --days 365     # prints a code like HMP-ABCD-EFGH-JKLM
    node license_server.js list
    node license_server.js revoke HMP-ABCD-EFGH-JKLM        # blocks it on the next online check
    node license_server.js unrevoke HMP-ABCD-EFGH-JKLM
    node license_server.js reset HMP-ABCD-EFGH-JKLM         # frees device slots (new phone)
    node license_server.js extend HMP-ABCD-EFGH-JKLM 90     # add 90 days

## What the system enforces
- A copy of the app without a valid code shows only the activation screen. The content stays encrypted.
- Each code works on a limited number of devices (default 2).
- Codes can expire or be revoked. Revoked phones lose access the next time they go online; offline use is allowed for at most 30 days.
- A watermark with the student's name and code tail is drawn on every screen, so leaked screenshots and photos can be traced.
- Too many attempts from one address are rejected.

## What it cannot do
A person with a valid licence can still photograph the screen or copy notes by hand, and a determined technical user on their own device can extract the content once unlocked. This is protection against casual sharing of the app file, not against a determined attacker. For stronger protection the content itself would have to be served from the server one card at a time.
